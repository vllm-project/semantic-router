"""Verify published point metrics using saved responses and unmodified JevBench.

This script has no inference path. It patches only the upstream HTTP transport
to return a saved response, leaving the pinned adapter and scorer unchanged.
"""

import argparse
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import sys
from unittest.mock import patch


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def quantile(values, p):
    values = sorted(values)
    x = (len(values) - 1) * p
    return values[math.floor(x)] * (1 - x % 1) + values[math.ceil(x)] * (x % 1)


def same(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (
        actual,
        expected,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jevbench", required=True, type=Path)
    parser.add_argument("--evidence", required=True, type=Path)
    args = parser.parse_args()
    upstream, evidence = args.jevbench.resolve(), args.evidence.resolve()
    manifest = json.loads((evidence / "evidence-manifest.json").read_text())
    for name, digest in manifest["files"].items():
        assert sha(evidence / name) == digest, name
    source = json.loads((evidence / "upstream-source-receipt.json").read_text())
    actual_commit = subprocess.check_output(
        ["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True
    ).strip()
    assert actual_commit == source["benchmark_commit"] == manifest["upstream_commit"]
    for name, digest in source["files"].items():
        assert sha(upstream / name) == digest, name
    # Also bind adapter dependencies to the immutable Git source, without
    # requiring the local checkout's unrelated generated outputs to be clean.
    for path in (upstream / "jevbench").rglob("*.py"):
        original = subprocess.check_output(
            [
                "git",
                "-C",
                str(upstream),
                "show",
                f"{actual_commit}:{path.relative_to(upstream)}",
            ]
        )
        assert path.read_bytes() == original, path
    sys.path.insert(0, str(upstream))
    from jevbench.adapters.typesafe import TypeSafeAdapter
    from jevbench.scoring import score_task
    from jevbench.tasks import load_jsonl

    tasks = {}
    for name in ("easy", "original", "hard"):
        for task in load_jsonl(str(upstream / f"datasets/public/{name}.jsonl")):
            assert task.id not in tasks
            tasks[task.id] = task
    assert len(tasks) == 231
    expected = json.loads((evidence / "figure-data.json").read_text())
    totals = collections.Counter()
    observed = set()
    eligibility = collections.Counter()
    correctness = {}
    for row in map(
        json.loads, (evidence / "quality-responses.jsonl").read_text().splitlines()
    ):
        key = (row["task_id"], row["arm"])
        assert key not in observed
        observed.add(key)
        assert row["pass"] == 0
        task = tasks[row["task_id"]]
        adapter = TypeSafeAdapter(
            endpoint="http://unused.invalid", model=row["response"]["model"], key_env=""
        )
        # The adapter creates its normal request but never sends it. Answers
        # retain their original semantic values, probabilities and ordering.
        with patch(
            "jevbench.adapters.typesafe.http_post_json",
            return_value=(row["http_status"], row["response"], 0.0),
        ) as transport:
            result = adapter.run(task)
        assert transport.call_count == 1
        complete = (
            row["response"]["answers"]["decision"].get("input_coverage") == "complete"
        )
        scored = (
            score_task(result.probs or {}, task)
            if result.ok
            else {"valid": False, "correct": False}
        )
        valid = result.ok and complete and scored["valid"]
        eligibility[row["arm"]] += int(valid)
        totals[row["arm"]] += int(valid and scored["correct"])
        correctness[key] = int(valid and scored["correct"])
    assert observed == {(task, arm) for task in tasks for arm in expected["quality"]}
    for arm, value in expected["quality"].items():
        assert totals[arm] == value["correct"]
        assert 231 - eligibility[arm] == value["unresolved"]
        same(totals[arm] / 231, value["accuracy"])
    measures = list(csv.DictReader((evidence / "measurements.csv").open(newline="")))
    assert len(measures) == 2079
    groups = collections.defaultdict(set)
    latency = {}
    for row in measures:
        groups[row["source_group"]].add(row["task_id"])
        latency[(row["pass"], row["arm"], row["task_id"])] = float(
            row["client_elapsed_ms"]
        )
    assert len(groups) == 195
    keys = sorted(groups)
    samples = []
    rng = random.Random(20261010)
    for _ in range(5000):
        samples.append([rng.choice(keys) for _ in keys])
    for baseline in ("direct_kai", "direct_vega"):
        group_gain = {
            g: sum(
                correctness[(task, "auto")] - correctness[(task, baseline)]
                for task in tasks
            )
            for g, tasks in groups.items()
        }
        differences = sorted(
            sum(group_gain[g] for g in sample) / sum(len(groups[g]) for g in sample)
            for sample in samples
        )
        for actual, reference in zip(
            (differences[124], differences[4874]),
            expected["paired_quality"][baseline]["ci95"],
        ):
            same(actual, reference)
    for index, entry in expected["passes"].items():
        group_latency = {
            arm: {
                g: sum(latency[(index, arm, task)] for task in tasks)
                for g, tasks in groups.items()
            }
            for arm in ("auto", "direct_vega")
        }
        ratios = sorted(
            sum(group_latency["auto"][g] for g in sample)
            / sum(group_latency["direct_vega"][g] for g in sample)
            for sample in samples
        )
        for actual, reference in zip(
            (ratios[124], ratios[4874]), entry["ratio_source_group_ci95"]
        ):
            same(actual, reference)
        for arm, value in entry["arms"].items():
            rows = [r for r in measures if r["pass"] == index and r["arm"] == arm]
            assert len(rows) == 231 and {r["task_id"] for r in rows} == set(tasks)
            values = [float(r["client_elapsed_ms"]) for r in rows]
            stats = {
                "mean": statistics.mean(values),
                "p50": quantile(values, 0.5),
                "p95": quantile(values, 0.95),
                "p99": quantile(values, 0.99),
            }
            for metric, actual in stats.items():
                same(actual, value["elapsed_ms"][metric])
            for model in ("kai", "vega"):
                assert (
                    sum(int(r[f"{model}_calls"]) for r in rows)
                    == value["physical_calls"][model]
                )
            assert (
                dict(collections.Counter(r["selected_model"] for r in rows))
                == value["served_by"]
            )
    print(
        json.dumps(
            {
                "status": "verified",
                "requests_rescored": len(observed),
                "timed_calls_recomputed": len(measures),
                "correct": dict(totals),
                "all_mean_and_quantile_metrics_match": True,
                "physical_call_counts_match": True,
                "no_model_calls": True,
                "paired_quality_and_mean_ratio_intervals_match": True,
                "limits": "This reproduces the recorded bootstrap, not a calibrated quality guarantee. No serving rerun or p95 interval.",
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
