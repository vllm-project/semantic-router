# System One Auto — recorded public-suite evidence

This package verifies the historical Kai 0.6B → Vega 27B comparison reported in
“System One Auto: Small First, Strong When It Counts.” It contains recorded
results, not a model server. No credential, endpoint or private infrastructure
identifier is needed to replay it.

## Verify without inference

Check out the exact public benchmark, then run this standard-library script:

```bash
git clone https://github.com/fstandhartinger/jevbench.git
git -C jevbench checkout --detach b6b8fff7e345b98c060ad26c13308860ddc67004
python3 replay_evidence.py --jevbench ../jevbench --evidence ./evidence
```

Adjust the checkout path to its actual location. The script verifies source and
data hashes, feeds 693 saved pass-0 responses through the unchanged JevBench
adapter/scorer with its HTTP transport mocked, and recalculates 2,079 recorded
latencies and native call counts. It also reproduces the recorded paired
source-group bootstrap intervals. It sends no model or network requests.

Expected quality totals out of 231: direct Kai 152; Auto 190; direct Vega 203.
Auto returns Kai for 125 requests and Vega for 106. The evidence does not claim
Vega-equivalent accuracy, a p95 improvement, a throughput win or a smaller GPU
bill. These are public-repository items, not the sealed v1.6.1 composite.

## Files and boundaries

- `quality-responses.jsonl`: every saved pass-0 native answer, with no private
  serving metadata. The other two passes do not increase the quality sample.
- `measurements.csv`: every timed frontend request, with native call deltas.
- `request-schedule.json` and `warmup-requests.json`: exact order and warmups for
  the integrated `systemone_auto jevbench` collector.
- `figure-data.json`: derived counts, latency summaries, intervals and limits.
- `evidence-manifest.json`: pinned checkpoint/runtime identities, measured
  source snapshot and image content digests, plus hashes of the public files.
- `upstream-source-receipt.json`: source/scorer/task-file hashes.
- `attribution/`: the pinned upstream license and third-party notice, copied
  verbatim. Their historical prose describes the upstream project; it is not
  this article's model list or request count. Benchmark task texts and labels
  remain in the upstream checkout rather than being duplicated in this archive.

The code and image receipts identify the historical run. They do not certify
any later product build. A new serving run needs a fresh record of the actual
source, configuration, model revision, numerical profile and loaded identities.
First-pass and warm latency are kept separate. The native numerical profile was
`exact` on ROCm; the online setup had two resident GPUs and concurrency one.

## Run a new comparison

Use `tools/calibration/systemone_auto` in the Semantic Router checkout and its
maintained README. Publish `kai`, `vega` and `vllm-sr/auto`; deploy the exact model
revisions and the predeclared threshold `0.6059704079536342`. Pass the schedule
and warmups in this archive to the collector. Verify the service loaded the
intended configuration; a local config hash alone cannot prove that.

Keep every planned failure and report it. Use pass 0 for quality and later
passes for timing only. Physical call metrics require dedicated runtimes with
no unrelated traffic; without counters, leave that evidence unknown. A new
application needs separate calibration and held-out evaluation.
